rootProject.name = "nmedia"
